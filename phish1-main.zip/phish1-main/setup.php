<?php
$color = '#ffffff'; // search hex colour picker in google
$image = 'https://cdn.discordapp.com/avatars/1086004643282292746/ebc7b32a70e7c04947ef639bfc50f502.png'; // get any image (must be url)
$name = 'Name'; // name for your site
$discordserver = 'https://discord.gg/invite'; // discord invite, must be starting with https://
$webhook = 'your webhook'; // discord webhook, make sure you put in the right webhook
?>