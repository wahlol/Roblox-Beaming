u need proxy for the login page to work!!!

also go to setup.php ($hex pick hex colour for ur triplehook like in what embed colour like the line gonna send in example : #00001= dark purple)

$image=(in what profile picture the bot is gonna send the beam in)

$name=(ur beam or notifier name like after they generate link the bots name gonna be = $name-notifier

$discordserver=(like if they want to find ur discord server and ur domain is like wmw-rolbox.com and after they paste the only domain its gonna popup ur discord server

$webhook=(to what webhook will ur beams be sended to)

u need to go to host and then use uzipper.php to unzip the file bc it wont work