<?php
header('content-type: application/json');
die(json_encode(array("previouspagecursor" => null,"nextpagecursor" => null,"data" => array())));
?>